getElementById("login-form");
addEventListener("submit", function (event) {
  event.preventDefault();

  var username = document.getElementById("username").value;
  var password = document.getElementById("password").value;

  // Simulating login process
  if (username === "admin" && password === "admin") {
    // Successful login
    alert("Login successful!");
    // Here you can redirect the user or do something else
  } else {
    // Failed login
    document.getElementById("error-msg").innerText =
      "Invalid username or password.";
  }
});
