<!DOCTYPE html>
<html>
<head>
    <title>Registro</title>
</head>
<body>
    <h2>Registro</h2>
    
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">

    <h2>Dados Pessoais</h2>

    <h4>Logado como: [nome]</h4><br>
    <h4>Complete o perfil</h4><br><br>

    <label for="idade">Idade<span id="spanObrigatorio">*</span></label>
    <input type="number" id="idade" name="idade" min="16" max="70" required><br><br>

    <label for="">Gênero<span id="spanObrigatorio">*</span></label>
    <select id="genero" name="genero" required>
      <option value="" disabled selected hidden> Selecione uma opção </option>
      <option value="masculino">Masculino</option>
      <option value="feminino">Feminino</option>
      <option value="outro">Outro</option>
    </select><br><br>

    <h2>Saúde:</h2>
    <label for="altura">Altura (cm)<span id="spanObrigatorio">*</span></label>
    <input type="number" id="altura" name="altura" min="155" max="210" required><br><br>

    <label for="peso">Peso (kg)<span id="spanObrigatorio">*</span></label>
    <input type="number" id="peso" name="peso" min="45" max="250" required><br><br>

    <label for="" >Objetivo do tipo de alimentação<span id="spanObrigatorio">*</span></label>
    <select id="objetivo" name="objetivo" required>
      <option value="" disabled selected hidden> Selecione uma opção </option>
      <option value="cut">Perder peso </option>
      <option value="bulk"> Ganhar massa muscular </option>
      <option value="energy">Estimumalação de energia </option>
    </select><br><br>

    <label for="alergias">Calorias alimentares<span id="spanObrigatorio">*</span></label><br>
    <textarea id="alergias" name="calorias" rows="4" cols="4" maxlength="200"></textarea><br><br>

    <label for="condicoes">restricoes alimentares</label><br>
    <textarea id="condicoes" name="alergia" rows="4" cols="4" maxlength="200"></textarea><br><br>

    <label for="fuma">Hábitos fumadores<span id="spanObrigatorio">*</span></label><br>
    <input type="radio" id="fuma-sim" name="fuma" value="sim">
    <label for="fuma-sim">Sim</label><br>
    <input type="radio" id="fuma-nao" name="fuma" value="nao">
    <label for="fuma-nao">Não</label><br><br>


    <h2>Outras Informações</h2>

    <label for="preferencia">Pratica atividade física:</label><br>
    <input type="checkbox" id="corrida" name="atividade[]" value="corrida">
    <label for="corrida">Corrida</label><br>
    <input type="checkbox" id="ginasio" name="atividade[]" value="ginasio">
    <label for="ginasio">Ginásio</label><br>
    <input type="checkbox" id="football" name="atividade[]" value="football">
    <label for="football">Football</label><br>
    <input type="checkbox" id="outroPreferencia" name="atividade[]" value="outroPreferencia">      
    <label for="nome" >Outros:</label><br>
    <input type="text" id="outroPreferencia" name="atividade[]" maxlength="100"><br><br>
  
    
    <input id="submit" type="submit" value="Enviar">
    <input type="reset" value="Limpar">

  </form>

  <?php
// Verificar se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Conexão com o banco de dados
    $servername = "localhost";
    $username = "root";
    $password = "mysql";
    $dbname = "nutri4u";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Verificar conexão
    if ($conn->connect_error) {
        die("Erro de conexão: " . $conn->connect_error);
    }

    // Receber dados do formulário e limpar espaços em branco extras falta nome a ligar com o id
    $idade = trim($_POST['idade']);
    $genero = trim($_POST['genero']);
    $altura = trim($_POST['altura']);
    $peso = trim($_POST['peso']);
    $objetivo = trim($_POST['objetivo']);
    $calorias = trim($_POST['calorias']);
    $restricoes_alimentares = trim($_POST['alergia']);
    $fuma = trim($_POST['fuma']);
    $atividades = isset($_POST['atividade']) ? implode(", ", $_POST['atividade']) : '';

    // Preparar e executar a consulta SQL para inserir os dados
    $sql = "INSERT INTO registros (idade, genero, altura, peso, objetivo, calorias, restricoes_alimentares, fuma, atividade) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    // Verificar se a preparação da consulta foi bem-sucedida
    if ($stmt) {
        // Vincular parâmetros
        $stmt->bind_param("isissssss", $idade, $genero, $altura, $peso, $objetivo, $calorias, $restricoes_alimentares, $fuma, $atividades);

        // Executar consulta
        if ($stmt->execute()) {
            echo "Dados inseridos com sucesso!";
        } else {
            echo "Erro ao executar a consulta: " . $stmt->error;
        }
    } else {
        // Se a preparação da consulta falhar, exibir mensagem de erro
        echo "Erro ao preparar a consulta: " . $conn->error;
    }

    // Fechar conexão
    $stmt->close();
    $conn->close();
}
?>


</body>
</html>