<!DOCTYPE html>
<html>
<head>
    <title>Registro</title>
</head>
<body>
    <h2>Registro</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
        Email: <input type="email" name="email" required><br>
        Senha: <input type="password" name="senha" required><br>
        <input type="submit" value="Registrar">
    </form>

    <?php
    // Conexão com o banco de dados
    $servername = "localhost";
    $username = "root";
    $password = "mysql";
    $dbname = "nutri4u";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Verificar a conexão
    if ($conn->connect_error) {
        die("Erro de conexão: " . $conn->connect_error);
    }

    // Verificar se os dados foram enviados através do método POST
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Receber dados do formulário
        $email = $_POST['email'];
        $senha = $_POST['senha'];

        // Verificar se o e-mail já está em uso
        $sql_check_email = "SELECT id FROM cadastro WHERE email=?";
        $stmt_check_email = $conn->prepare($sql_check_email);
        $stmt_check_email->bind_param("s", $email);
        $stmt_check_email->execute();
        $stmt_check_email->store_result();

        if ($stmt_check_email->num_rows > 0) {
            echo "Este e-mail já está em uso.";
            $stmt_check_email->close();
            $conn->close();
            exit();
        }

        // Hash de senha
        $senha_hash = password_hash($senha, PASSWORD_DEFAULT);

        // Inserir dados no banco de dados usando declaração preparada
        $sql_insert = "INSERT INTO cadastro (email, pass) VALUES (?, ?)";
        $stmt_insert = $conn->prepare($sql_insert);
        $stmt_insert->bind_param("ss", $email, $senha_hash);

        if ($stmt_insert->execute()) {
            // Registro bem-sucedido, redirecionar para a página de login
            header("Location: login.php");
            exit();
        } else {
            echo "Erro ao registrar: " . $stmt_insert->error;
        }

        $stmt_insert->close();
    }

    $conn->close();
    ?>
</body>
</html>



