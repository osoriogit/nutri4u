<!DOCTYPE html>
<html>
<head>
    <title>Dados Recebidos</title>
</head>
<body>
    <h2>Dados Recebidos</h2>
    <?php
    // Verificar se os dados foram enviados através do método POST
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Receber e exibir os dados recebidos do formulário
        $email = $_POST['email'];
        $senha = $_POST['senha'];

        echo "<p>Email: $email</p>";
        echo "<p>Senha: $senha</p>";
    } else {
        echo "<p>Nenhum dado recebido.</p>";
    }
    ?>
</body>
</html>
