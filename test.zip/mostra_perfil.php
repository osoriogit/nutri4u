<?php
// Conexão com o banco de dados
$servername = "localhost";
$username = "root";
$password = "mysql";
$dbname = "nutri4u";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexão
if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

// Consulta SQL para selecionar todos os registros da tabela
$sql = "SELECT * FROM registros";
$result = $conn->query($sql);

// Verificar se há resultados na consulta
if ($result->num_rows > 0) {
    // Exibir os dados em uma tabela HTML
    echo "<table border='1'>
            <tr>
                <th>Idade</th>
                <th>Gênero</th>
                <th>Altura</th>
                <th>Peso</th>
                <th>Objetivo</th>
                <th>Calorias</th>
                <th>Restrições Alimentares</th>
                <th>Fuma</th>
                <th>Atividade</th>
            </tr>";

    // Iterar sobre os resultados e exibir cada registro na tabela
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . $row["idade"] . "</td>
                <td>" . $row["genero"] . "</td>
                <td>" . $row["altura"] . "</td>
                <td>" . $row["peso"] . "</td>
                <td>" . $row["objetivo"] . "</td>
                <td>" . $row["calorias"] . "</td>
                <td>" . $row["restricoes_alimentares"] . "</td>
                <td>" . $row["fuma"] . "</td>
                <td>" . $row["atividade"] . "</td>
              </tr>";
    }

    echo "</table>";
} else {
    echo "Nenhum resultado encontrado na tabela.";
}

// Fechar conexão
$conn->close();
?>
