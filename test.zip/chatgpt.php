<?php
// Conexão com o banco de dados
$servername = "localhost";
$username = "root";
$password = "mysql";
$dbname = "nutri4u";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexão
if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

// Consulta SQL para recuperar o texto da base de dados
$sql = "SELECT * FROM registros WHERE id = 2"; // Substitua 'tabela_texto' pelo nome da sua tabela
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $texto = $row["texto"];

    // Fechar conexão
    $conn->close();

    // Enviar o texto para o GPT-3
    $url = 'https://api.openai.com/v1/completions';
    $data = array(
        'model' => 'text-davinci-003', // Modelo do GPT-3
        'prompt' => $texto,
        'max_tokens' => 100
    );
    $headers = array(
        'Content-Type: application/json',
        'Authorization: Bearer YOUR_API_KEY' // Substitua YOUR_API_KEY pela sua chave de API do OpenAI
    );

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $response = curl_exec($ch);
    curl_close($ch);

    // Processar e armazenar a resposta na base de dados
    // Por exemplo, você pode executar outra consulta SQL para armazenar a resposta na sua base de dados
    // Certifique-se de sanitizar e validar os dados antes de inseri-los na base de dados

    echo "Resposta do GPT-3: " . $response;
} else {
    echo "Nenhum texto encontrado na base de dados.";
}

?>
