// Se necessario.
