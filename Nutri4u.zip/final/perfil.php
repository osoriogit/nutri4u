<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Nutri4u - Perfil</title>
    <link rel="icon" href="imgs/OIG1.png" type="image/png"/>
    <link rel="stylesheet" href="styles.css" />
    <style>
        .botao{
    display: flex;
    padding: 10px 20px;
    background-color: #d7f4d6;
    color: white;		   
    border: none;
    border-radius: 12px;
    cursor: pointer;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
    background: linear-gradient(to bottom, #4CAF50, #45a049);
    transition: background 0.3s ease, color 0.3s ease;
    margin: 0 10px;
    box-shadow: 0px 8px 12px rgba(0, 0, 0, 0.5);
}

.botao:hover{
  background: linear-gradient(to bottom, #ffffff, #ffffff);
    color: #4CAF50;
}

#last{
    display:flex;
    text-align: center;
    margin-top: 20px;
}
    </style>
</head>
<body>
    <div class="container">
        <div class="left">
            <h2>Dados Pessoais</h2>
            <div class="personal-data">
                <?php include 'mostra_perfil.php'; ?>
                
                <div id="last">
                    <button class="botao">Nova Dieta</button>
                    <button class="botao">Uber Eats</button>
                </div>
                
            </div>
        </div>
        <div class="right">
            <h2>Dieta Sugerida</h2>
            <div class="questionnaire-result" id="tabelaDieta">
                <!-- A tabela de dieta sugerida será inserida aqui -->
            </div>
        </div>
    </div>
    <script>
        // Texto com os dados da dieta
        var textoDieta = "Segunda-feira: Pequeno-almoço: Omelete de 1 ovo e 2 claras de ovo com espinafres. Almoço: Salada de folhas verdes com pepino, tomate e pimento + 50g de peito de frango grelhado. Lanche da tarde: 1 iogurte natural magro. Jantar: 100g de salmão grelhado + 1 chávena de brócolos cozidos a vapor. Terça-feira: Pequeno-almoço: 1/2 chávena de aveia cozida com água + 1/2 banana fatiada. Almoço: 50g de carne magra + 1 batata-doce pequena cozida + Salada de vegetais com 1 colher de chá de azeite. Lanche da tarde: 1 fatia de queijo branco magro + 1 cenoura pequena crua. Jantar: 1 prato de sopa de legumes + 1 fatia de pão integral. Quarta-feira: Pequeno-almoço: Smoothie com 1/2 chávena de leite magro, 1/2 chávena de morangos, 1/2 banana e 1 colher de sopa de aveia. Almoço: 1 filé de frango grelhado + 1 chávena de legumes mistos cozidos a vapor. Lanche da tarde: 1 punhado de amêndoas + 1 maçã pequena. Jantar: Omelete de 2 claras de ovo com vegetais + 1 fatia de queijo branco. Quinta-feira: Pequeno-almoço: 1 iogurte natural magro + 1/2 chávena de mirtilos. Almoço: Salada de quinoa com pepino, tomate, pimento e salsa. Lanche da tarde: 1 barra de cereais de baixa caloria. Jantar: 100g de salmão grelhado + 1 chávena de espargos cozidos a vapor. Sexta-feira: Pequeno-almoço: Omelete de 1 ovo com 2 claras de ovo com espinafres. Almoço: Salada de folhas verdes com frango desfiado, pepino, tomate e cenoura ralada. Lanche da tarde: 1 iogurte natural magro + 1/2 pêra. Jantar: 100g de carne magra grelhada + 1 chávena de legumes mistos cozidos a vapor. Sábado: Pequeno-almoço: Smoothie com 1/2 chávena de leite de amêndoa, 1/2 banana, 1/2 chávena de morangos e 1 colher de sopa de sementes de chia. Almoço: Wrap de frango com alface, tomate e 1 tortilha integral. Lanche da tarde: 1 punhado de nozes + 1/2 manga. Jantar: Sopa de legumes + 1 fatia de pão integral. Domingo: Pequeno-almoço: Omelete de 2 claras de ovo com espinafres e cogumelos. Almoço: Salada de atum com alface, tomate, pepino e 1 colher de chá de azeite. Lanche da tarde: 1 iogurte natural magro + 1/2 banana. Jantar: 100g de peixe branco grelhado + 1 chávena de brócolos cozidos a vapor.";

        // Dividir o texto em dias da semana e refeições
        var dieta = textoDieta.split(/(Segunda-feira|Terça-feira|Quarta-feira|Quinta-feira|Sexta-feira|Sábado|Domingo):/);

        // Inicializar a tabela HTML
        var tabelaHTML = "<table>";
        tabelaHTML += "<tr><th>Dia da Semana</th><th>Pequeno-almoço</th><th>Almoço</th><th>Lanche</th><th>Jantar</th></tr>";

        // Iterar sobre a dieta e adicionar os dados à tabela HTML
        for (var i = 1; i < dieta.length; i += 2) {
            var diaSemana = dieta[i];
            var refeicoes = dieta[i + 1].split(/Pequeno-almoço:|Almoço:|Lanche da tarde:|Jantar:/);
            tabelaHTML += "<tr>";
            tabelaHTML += "<td>" + diaSemana.trim() + "</td>";
            for (var j = 1; j < refeicoes.length; j++) {
                tabelaHTML += "<td>" + refeicoes[j].trim() + "</td>";
            }
            tabelaHTML += "</tr>";
        }

        tabelaHTML += "</table>";

        // Adicionar a tabela HTML à div
        document.getElementById("tabelaDieta").innerHTML = tabelaHTML;
    </script>
</body>
</html>

