<?php
// Verificar se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Conexão com o banco de dados
    $servername = "localhost";
    $username = "root";
    $password = "mysql";
    $dbname = "nutri4u";

    // Criar conexão
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Verificar conexão
    if ($conn->connect_error) {
        die("Erro de conexão: " . $conn->connect_error);
    }

    // Receber dados do formulário
    $nome = $_POST['nome'];
    $peso1 = $_POST['peso1'];
    $peso2 = $_POST['peso2'];
    $idade = $_POST['idade'];
    $genero = $_POST['genero'];
    $altura = $_POST['altura'];
    $restricoes_alimentares = $_POST['calorias'];
    $objetivo = $_POST['objetivo'];
    $fuma = $_POST['fuma'];
    $atividade = isset($_POST['atividade']) ? implode(", ", $_POST['atividade']) : '';
    $id =2;
    // Preparar e executar a consulta SQL para inserir os dados
    $sql = "INSERT INTO registros (id, nome, peso1, peso2, idade, genero, altura, restricoes_alimentares, objetivo, fuma, atividade) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    // Verificar se a preparação da consulta foi bem-sucedida
    if ($stmt === false) {
        die("Erro ao preparar a consulta: " . $conn->error);
    }

    // Vincular parâmetros
    $stmt->bind_param("isddissssss", $id, $nome, $peso1, $peso2, $idade, $genero, $altura, $restricoes_alimentares, $objetivo, $fuma, $atividade);

    // Executar consulta
    if ($stmt->execute()) {
        header("Location: ../perfil.php");
        exit();
    }

    // Fechar conexão
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Nutri4u - Formulário pessoal</title>
    <link rel="icon" href="imgs/OIG1.png" type="image/png"/>
    <link rel="stylesheet" href="batata.css">
    <script type="text/javascript" src="test.js"> </script>
    <meta charset="UTF-8">
</head>
<body>

    <form id="form1">
        <h2>Formulário pessoal</h2>
    </form>
    
    <form id="form2" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" onsubmit="return validarForm();">
    
        <label for="nome">Nome<span id="spanObrigatorio">*</span></label>
        <input type="text" id="nome"  name="nome" placeholder="Maria" maxlength="160" required><br><br>


        <div id="ki" class="flex11">
            <div id="camposDup">
                <label for="idade">Idade<span id="spanObrigatorio">*</span></label>
                <input type="number" id="idade" pattern="[0-9]*" placeholder="50" name="idade" min="16" step="1" max="80" required><br><br>
            </div>
           
            <div id="camposDup">
                <label for="peso">Peso (kg)<span id="spanObrigatorio">*</span></label>
                <input type="number" id="peso1" pattern="[0-9]*" placeholder="90" name="peso1" min="45" step="5" max="250" required><br><br>
            </div>
        </div>

        <div id="ko" class="flex11">
            <div id="camposDup">
                <label for="altura">Altura (cm)<span id="spanObrigatorio">*</span></label>
                <input type="number" id="altura" pattern="[0-9]*" placeholder="180" name="altura" min="145" step="5" max="220" required><br><br>
            </div>
            
            <div id="camposDup">
                <label for="peso">Objetivo peso (kg)<span id="spanObrigatorio">*</span></label>
                <input type="number" id="peso2" pattern="[0-9]*" placeholder="75" name="peso2" min="45" step="5" max="100" required><br><br>
            </div>
        </div>

        <label for="" >Objetivo do tipo de alimentação<span id="spanObrigatorio">*</span></label>
        <select id="objetivo" name="objetivo" required>
            <option value="" disabled selected hidden> Selecione uma opção </option>
            <option value="cut">Perder peso </option>
            <option value="bulk"> Ganhar massa muscular </option>
            <option value="energy">Estimulação de energia </option>
        </select>

        <label for="">Gênero<span id="spanObrigatorio">*</span></label>
            <select id="genero" name="genero" required>
                <option value="" disabled selected hidden> Selecione uma opção </option>
                <option value="masculino">Masculino</option>
                <option value="feminino">Feminino</option>
                <option value="outro">Outro</option>
            </select>
        

        <label for="alergias">Doenças, alergias e restrições alimentares</label><br>
        <textarea type="text" id="alergias" pattern="[A-Za-z,;]+" placeholder="Anemia, diabetes, glúten, laticínios..." name="calorias" rows="3" cols="4" maxlength="200"></textarea><br><br>

        <div id="down">
            <div id="habitos">
                <label for="fuma">Hábitos tabagísticos<span id="spanObrigatorio" required>*</span></label><br>
                    <input type="radio" id="fuma-nao" name="fuma" value="nao" onclick="fuma()">
                    <label for="fuma-nao">Não</label><br>
                    <input type="radio" id="fuma-sim" name="fuma" value="sim" onclick="fuma()">
                    <label for="fuma-sim">Sim</label><br><br>
            </div>
            <div id="habitos">
                <label for="frequencia">Frequência de atividade física (por semana)<span id="spanObrigatorio">*</span></label><br>
                    <input type="radio" id="atividade0" name="atividade[]" value="Nehuma" onclick="frequencia()">
                    <label for="atividade0">Nenhuma</label><br>
                    <input type="radio" id="atividade1_2" name="atividade[]" value="1 a 2" onclick="frequencia()">
                    <label for="atividade1_2">1 a 2 vezes</label><br>
                    <input type="radio" id="atividade3_5" name="atividade[]" value="3 a 5" onclick="frequencia()">
                    <label for="atividade3_5">3 a 5 vezes</label><br>
                    <input type="radio" id="atividade5plus" name="atividade[]" value="5 ou mais" onclick="frequencia()">      
                    <label for="atividade5plus">5 ou mais vezes</label><br><br>
                </div>
        </div>

        <div id="last"> 
            <input id="submit" type="submit" value="Enviar" onclick="window.location.href='../perfil.php'">
            <input id="reset" type="reset" value="Limpar">
        </div>

        <br><br>
        <div id="error-popup">
            <span id="spanObrigatorio">* </span> <a> (Campos obrigatórios)</a>
        </div>

    </form>
   


</body>
</html>