function fuma() {
  var fumaNao = document.getElementById("fuma-nao");
  var fumaSim = document.getElementById("fuma-sim");

  if (!(fumaNao.checked || fumaSim.checked)) {
      alert("[Hábitos tabagísticos]: Seleciona uma opção!");
      return false;
  }
  return true;
}

function frequencia() {
  var atividade0 = document.getElementById("atividade0");
  var atividade1_2 = document.getElementById("atividade1_2");
  var atividade3_5 = document.getElementById("atividade3_5");
  var atividade5plus = document.getElementById("atividade5plus");

  if (!(atividade0.checked || atividade1_2.checked || atividade3_5.checked || atividade5plus.checked)) {
      alert("[Frequência de atividade física]: Seleciona uma opção!");
      return false;
  }
  return true;
}

function validarForm() {
  var opcaoSelecionada = document.getElementById('genero').value;
  if (opcaoSelecionada === '') {
      alert('Seleciona uma opção válida!');
      return false;
  }
  var fumaValido = fuma();
  var frequenciaValida = frequencia(); 

  if (!fumaValido || !frequenciaValida) {
      return false;
  }
  return true;
}
