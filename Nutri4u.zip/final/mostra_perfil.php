<?php
// Conexão com o banco de dados
    $servername = "localhost";
    $username = "root";
    $password = "mysql";
    $dbname = "nutri4u";
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexão
if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

// Consulta SQL para recuperar os dados pessoais da base de dados
$sql_dados_pessoais = "SELECT nome, peso1, idade, genero, altura, restricoes_alimentares, atividade FROM registros WHERE id = 2"; // Substitua 'dados_pessoais' pelo nome da sua tabela
$result_dados_pessoais = $conn->query($sql_dados_pessoais);

if ($result_dados_pessoais->num_rows > 0) {
    // Exibir os dados pessoais
    while($row = $result_dados_pessoais->fetch_assoc()) {
        echo '<div class="personal-data">';
        echo '<p><strong>Nome:</strong> ' . $row["nome"] . '</p>';
        echo '<p><strong>Peso:</strong> ' . $row["peso1"] . '</p>';
        echo '<p><strong>Idade:</strong> ' . $row["idade"] . '</p>';
        echo '<p><strong>Gênero:</strong> ' . $row["genero"] . '</p>';
        echo '<p><strong>Altura:</strong> ' . $row["altura"] . '</p>';
        echo '<p><strong>Restrições Alimentares:</strong> ' . $row["restricoes_alimentares"] . '</p>';
        echo '<p><strong>Atividade Física:</strong> ' . $row["atividade"] . '</p>';
        echo '</div>';
    }
} else {
    echo "Nenhum dado pessoal encontrado.";
}

$conn->close();
?>
