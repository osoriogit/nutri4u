-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Tempo de geração: 21-Abr-2024 às 13:17
-- Versão do servidor: 8.0.36
-- versão do PHP: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `nutri4u`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `cadastro`
--

CREATE TABLE `cadastro` (
  `id` int NOT NULL,
  `pass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `cadastro`
--

INSERT INTO `cadastro` (`id`, `pass`, `email`) VALUES
(1, 'ze', 'ze@gmail.com'),
(2, '$2y$10$fOm72mOG9ZhkRuLDLTCqVeltgGAb223i13XHcJLgmACL0DohR9xrG', 'tiagogfilipe@gmail.com'),
(3, '$2y$10$pxKXESxrcvqVNobcajQ2DuAF.9Yo0ynfmqg7C/CpV.KiFH2Z6N.ve', 'a2019112767@isec.pt');

-- --------------------------------------------------------

--
-- Estrutura da tabela `dietas`
--

CREATE TABLE `dietas` (
  `id` int NOT NULL,
  `dieta` text COLLATE utf8mb4_general_ci NOT NULL,
  `objetivo` enum('Perda de Peso','Manutenção','Ganho de Peso') COLLATE utf8mb4_general_ci DEFAULT NULL,
  `id_nome` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `dietas`
--

INSERT INTO `dietas` (`id`, `dieta`, `objetivo`, `id_nome`) VALUES
(1, 'Segunda-feira:\r\n\r\nPequeno-almoço: Omelete de 1 ovo e 2 claras de ovo com espinafres.\r\nAlmoço: Salada de folhas verdes com pepino, tomate e pimento + 50g de peito de frango grelhado.\r\nLanche da tarde: 1 iogurte natural magro.\r\nJantar: 100g de salmão grelhado + 1 chávena de brócolos cozidos a vapor.\r\nTerça-feira:\r\n\r\nPequeno-almoço: 1/2 chávena de aveia cozida com água + 1/2 banana fatiada.\r\nAlmoço: 50g de carne magra + 1 batata-doce pequena cozida + Salada de vegetais com 1 colher de chá de azeite.\r\nLanche da tarde: 1 fatia de queijo branco magro + 1 cenoura pequena crua.\r\nJantar: 1 prato de sopa de legumes + 1 fatia de pão integral.\r\nQuarta-feira:\r\n\r\nPequeno-almoço: Smoothie com 1/2 chávena de leite magro, 1/2 chávena de morangos, 1/2 banana e 1 colher de sopa de aveia.\r\nAlmoço: 1 filé de frango grelhado + 1 chávena de legumes mistos cozidos a vapor.\r\nLanche da tarde: 1 punhado de amêndoas + 1 maçã pequena.\r\nJantar: Omelete de 2 claras de ovo com vegetais + 1 fatia de queijo branco.\r\nQuinta-feira:\r\n\r\nPequeno-almoço: 1 iogurte natural magro + 1/2 chávena de mirtilos.\r\nAlmoço: Salada de quinoa com pepino, tomate, pimento e salsa.\r\nLanche da tarde: 1 barra de cereais de baixa caloria.\r\nJantar: 100g de salmão grelhado + 1 chávena de espargos cozidos a vapor.\r\nSexta-feira:\r\n\r\nPequeno-almoço: Omelete de 1 ovo com 2 claras de ovo com espinafres.\r\nAlmoço: Salada de folhas verdes com frango desfiado, pepino, tomate e cenoura ralada.\r\nLanche da tarde: 1 iogurte natural magro + 1/2 pêra.\r\nJantar: 100g de carne magra grelhada + 1 chávena de legumes mistos cozidos a vapor.\r\nSábado:\r\n\r\nPequeno-almoço: Smoothie com 1/2 chávena de leite de amêndoa, 1/2 banana, 1/2 chávena de morangos e 1 colher de sopa de sementes de chia.\r\nAlmoço: Wrap de frango com alface, tomate e 1 tortilha integral.\r\nLanche da tarde: 1 punhado de nozes + 1/2 manga.\r\nJantar: Sopa de legumes + 1 fatia de pão integral.\r\nDomingo:\r\n\r\nPequeno-almoço: Omelete de 2 claras de ovo com espinafres e cogumelos.\r\nAlmoço: Salada de atum com alface, tomate, pepino e 1 colher de chá de azeite.\r\nLanche da tarde: 1 iogurte natural magro + 1/2 banana.\r\nJantar: 100g de peixe branco grelhado + 1 chávena de brócolos cozidos a vapor.', 'Perda de Peso', 3);

-- --------------------------------------------------------

--
-- Estrutura da tabela `registros`
--

CREATE TABLE `registros` (
  `id` int NOT NULL,
  `nome` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `peso1` decimal(5,2) DEFAULT NULL,
  `peso2` decimal(10,0) DEFAULT NULL,
  `idade` int DEFAULT NULL,
  `genero` enum('Masculino','Feminino','Outro') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `altura` int DEFAULT NULL,
  `restricoes_alimentares` text COLLATE utf8mb4_general_ci,
  `objetivo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `calorias` int DEFAULT NULL,
  `fuma` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `atividade` varchar(255) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `registros`
--

INSERT INTO `registros` (`id`, `nome`, `peso1`, `peso2`, `idade`, `genero`, `altura`, `restricoes_alimentares`, `objetivo`, `calorias`, `fuma`, `atividade`) VALUES
(1, 'ze', 80.00, 0, 23, 'Masculino', 2, NULL, 'Perda de Peso', NULL, 'sim', ''),
(2, 'Ana Carla Vicente Vieira', 45.00, 60, 16, 'Masculino', 145, '', 'bulk', NULL, 'nao', '1 a 2');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `cadastro`
--
ALTER TABLE `cadastro`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `dietas`
--
ALTER TABLE `dietas`
  ADD KEY `fk_id_nome` (`id_nome`);

--
-- Índices para tabela `registros`
--
ALTER TABLE `registros`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `cadastro`
--
ALTER TABLE `cadastro`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `registros`
--
ALTER TABLE `registros`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `dietas`
--
ALTER TABLE `dietas`
  ADD CONSTRAINT `fk_id_nome` FOREIGN KEY (`id_nome`) REFERENCES `cadastro` (`id`);

--
-- Limitadores para a tabela `registros`
--
ALTER TABLE `registros`
  ADD CONSTRAINT `registros_ibfk_1` FOREIGN KEY (`id`) REFERENCES `cadastro` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
